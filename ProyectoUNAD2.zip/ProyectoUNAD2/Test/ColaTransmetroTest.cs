using System;
using ProyectoUNAD2.COLA;
using NUnit.Framework;

namespace ProyectoUNAD2.Test{

[TestFixture]
class ColaTransmetroTest {
    
    [Test]
    public void ingresarPasajero_Exitoso(){

        Cliente cliente = new Cliente(1,2, "juan", "boquilla");
        ColaTransmetro cola = new ColaTransmetro();
        
        cola.ingresarPasajero(cliente);
        int cantidad_clientes = cola.contarClientes();
        Boolean probar_inserccion = cantidad_clientes >= 1;

        Assert.IsTrue(probar_inserccion);
    }

    [Test]

    public void eliminarPasajero_Exitoso(){

        Cliente cliente = new Cliente(1,2, "juan", "boquilla");
        ColaTransmetro cola = new ColaTransmetro();
        
        cola.ingresarPasajero(cliente);
        cola.eliminarPasajero();
        int cantidad_clientes = cola.contarClientes();
        Boolean probar_eliminacion = cantidad_clientes == 0;

        Assert.IsTrue(probar_eliminacion);
    }


}
}