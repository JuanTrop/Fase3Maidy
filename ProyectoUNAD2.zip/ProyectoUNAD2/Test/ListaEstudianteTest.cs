using System;
using ProyectoUNAD2.LISTA;
using NUnit.Framework;
using System.Globalization;

namespace ProyectoUNAD2.Test
{
    [TestFixture]
    public class ListaEstudianteTest {

        [Test]
        public void insertarEstudiante_exitoso(){
            long ticks = new DateTime(2020, 11, 8, 22, 35, 5,
            new CultureInfo("en-US", false).Calendar).Ticks;
            DateTime dt = new DateTime(ticks);
            Estudiante juan = new Estudiante("juan",23,3,"ingenieria de sistemas", "piedra de bolivar", "UdeC", dt);
            ListaEstudiante lista = new ListaEstudiante();

            lista.insertarEstudiante(juan);
            int cantidad_estudiantes = lista.contarEstudiantes();
            Boolean probar_inserccion = cantidad_estudiantes >= 1;

            Assert.IsTrue(probar_inserccion);
        }

        [Test]
        public void eliminarEstudiante_exitoso(){
            long ticks = new DateTime(2020, 11, 8, 22, 35, 5,
            new CultureInfo("en-US", false).Calendar).Ticks;
            DateTime dt = new DateTime(ticks);
            Estudiante juan = new Estudiante("juan",23,3,"ingenieria de sistemas", "piedra de bolivar", "UdeC", dt);
            ListaEstudiante lista = new ListaEstudiante();

            lista.insertarEstudiante(juan);    
            lista.eliminarEstudiante(0);
            int cantidad_estudiantes = lista.contarEstudiantes();
            Boolean probar_eliminacion = cantidad_estudiantes == 0;

            Assert.IsTrue(probar_eliminacion);
        }
    }    
}