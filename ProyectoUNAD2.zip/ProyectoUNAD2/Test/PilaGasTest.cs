using System;
using ProyectoUNAD2.PILA;
using NUnit.Framework;
using System.Globalization;

namespace ProyectoUNAD2.Test
{
    [TestFixture]
    public class PilaGasTest{
        
        [Test]
        public void insertarFactura_exitoso(){
            long ticks = new DateTime(2020, 11, 8, 22, 35, 5,
            new CultureInfo("en-US", false).Calendar).Ticks;
            DateTime dt = new DateTime(ticks);
            FacturaGas juan = new FacturaGas(1,1,dt,100, "boquilla", "juan", 1, 2);
            PilaGas pila = new PilaGas();

            pila.insertarFactura(juan);
            int cantidad_facturas = pila.contarFacturas();
            Boolean probar_inserccion = cantidad_facturas >= 1;

            Assert.IsTrue(probar_inserccion);
        }

        [Test]
        public void eliminarFactura_exitoso(){
            long ticks = new DateTime(2020, 11, 8, 22, 35, 5,
            new CultureInfo("en-US", false).Calendar).Ticks;
            DateTime dt = new DateTime(ticks);
            FacturaGas juan = new FacturaGas(1,1,dt,100, "boquilla", "juan", 1, 2);
            PilaGas pila = new PilaGas();

            pila.insertarFactura(juan);
            pila.eliminarFactura();
            int cantidad_facturas = pila.contarFacturas();
            Boolean probar_eliminacion = cantidad_facturas == 0;
            Assert.IsTrue(probar_eliminacion);
        }

        [Test]
        public void saldoFacturas_exitoso(){
            long ticks = new DateTime(2020, 11, 8, 22, 35, 5,
            new CultureInfo("en-US", false).Calendar).Ticks;
            DateTime dt = new DateTime(ticks);
            FacturaGas juan = new FacturaGas(1,1,dt,100, "boquilla", "juan", 1, 2);
            PilaGas pila = new PilaGas();

            pila.insertarFactura(juan);
            double saldo = pila.getSaldo();
            Boolean saldo_modificado = saldo > 0;

            Assert.IsTrue(saldo_modificado);
        }
        
    }
}