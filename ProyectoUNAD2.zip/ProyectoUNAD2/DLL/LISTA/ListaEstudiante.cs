using System;
using System.Collections.Generic;

namespace ProyectoUNAD2.LISTA
{
    
public class ListaEstudiante {
    private List<Estudiante> listaEstudiantes;

    public ListaEstudiante(){
        this.listaEstudiantes = new List<Estudiante>();
    }

    public void insertarEstudiante(Estudiante estudiante){
        this.listaEstudiantes.Add(estudiante);
    }

    public void eliminarEstudiante(int index){
        this.listaEstudiantes.RemoveAt(index);
    }

    public int contarEstudiantes(){
        return this.listaEstudiantes.Count;
    }
}

}