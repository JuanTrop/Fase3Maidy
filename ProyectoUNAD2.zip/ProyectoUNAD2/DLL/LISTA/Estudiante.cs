using System;

namespace ProyectoUNAD2.LISTA{

public class Estudiante {
    private string nombre;

    private int edad;

    private int estrato;

    private string programa;

    private string sede_universidad;
    private string nombre_universidad;

    private DateTime fecha_control;

    public Estudiante(String nombre, int edad, int estrato, String programa, String sede_universidad, String nombre_universidad, DateTime fecha_control){
        this.nombre = nombre;
        this.edad = edad;
        this.estrato = estrato;
        this.programa = programa;
        this.sede_universidad = sede_universidad;
        this.nombre_universidad = nombre_universidad;
        this.fecha_control = fecha_control;

    }
}
}