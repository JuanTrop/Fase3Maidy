using System;
using System.Collections.Generic;

namespace ProyectoUNAD2.COLA
{

public class ColaTransmetro {
    private Queue<Cliente> colaTransmetro;

    public ColaTransmetro (){
        this.colaTransmetro = new Queue<Cliente>();
    }

    public void ingresarPasajero(Cliente cliente){
        this.colaTransmetro.Enqueue(cliente);
    }

    public int contarClientes(){
        return colaTransmetro.Count;
    }

    public void eliminarPasajero(){
        colaTransmetro.Dequeue();
    }

}

}