using System;

namespace ProyectoUNAD2.COLA
{

public class Cliente {
    private int id_ruta;

    private int num_bus;

    private string nombre_cliente;

    private string nombre_ruta;

    public Cliente(int id_ruta, int num_bus, string nombre_cliente, string nombre_ruta)
    {
        this.id_ruta = id_ruta;
        this.num_bus = num_bus;
        this.nombre_cliente = nombre_cliente;
        this.nombre_ruta = nombre_ruta;
    }
}
}