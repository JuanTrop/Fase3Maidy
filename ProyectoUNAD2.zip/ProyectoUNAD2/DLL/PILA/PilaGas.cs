using System;
using System.Collections.Generic;

namespace ProyectoUNAD2.PILA
{
    
public class PilaGas{
    private double saldo;
    private Stack<FacturaGas> stackFacturas; 

    public PilaGas(){
        this.saldo = 0;
        this.stackFacturas = new Stack<FacturaGas>(); 
    } 
    public void insertarFactura(FacturaGas factura){
        this.saldo += factura.getConsum();
        stackFacturas.Push(factura);
    }

    public FacturaGas eliminarFactura(){
        FacturaGas salida = this.stackFacturas.Pop();
        this.saldo = this.saldo - salida.getConsum();
        return salida;
    }

    public int contarFacturas(){
        return this.stackFacturas.Count;
    }

    public double getSaldo(){
        return this.saldo;
    }


}
}