using System;

namespace ProyectoUNAD2.PILA 
{
    
public class FacturaGas {
    
    private int id_ref ;
    private int num_f;
    private DateTime month ;
    private float consum ;
    private string c_address ;
    private string c_name ;
    private int c_layer ;
    private int c_category;
    
    public FacturaGas(int id_ref, int num_f, DateTime month, float consum, string c_address, string c_name, int c_layer, int c_category){
        this.id_ref = id_ref;
        this.num_f = num_f;
        this.month = month;
        this.consum = consum;
        this.c_address = c_address;
        this.c_name = c_name;
        this.c_layer = c_layer;
        this.c_category = c_category;

    }

    public void setConsum(float consum){
        this.consum = consum;
    }

    public float getConsum(){
        return this.consum;
    }
}
}